/*
 *  Projet Casse Brique.
 */

#include "casse_brique.h"

/* Largeur et hauteur par defaut d'une fenetre correspondant a nos criteres */

int main(int argc, char **argv)
{
	initialiseGfx(argc, argv); // Initialisation de l'acceleration graphique si elle existe

	// On ouvre la fenetre de notre application
	prepareFenetreGraphique("OpenGL", 600 , 400);

	/* Lance la boucle GLUT et aiguille les evenements sur la fonction gestionEvenements ci-apres,
		qui elle-meme utilise fonctionAffichagqe ci-dessous */
	lanceBoucleEvenements();

	return 0;
}

// La fonction de gestion des evenements, appelee automatiquement par le systeme
// des qu'une evenement survient.
// Le but est que ce soit le systeme qui gere quand il est necessaire de faire un trace,
// qui suive les actions sur la souris et le clavier, etc.
// Il ne nous reste plus qu'a reagir en fonction de ces evenements

void gestionEvenement(EvenementGfx evenement)
{

	static int etat = 0;

	switch (evenement) // En fonction de l'evenement envoye par le systeme...
	
	{

		case Initialisation: // Le message "Initialisation" est envoye une seule fois, au debut du programme
			{
				ecrisChaine( "////////////////////////////\n/ Evenement Initialisation /\n////////////////////////////\n");		 	
				 //lance en boucle le case affichage
				affiche_menu();
				initImage();
				demandeAnimation_ips(100);
			}
			break;
		
		case Affichage: 
			{
				effaceFenetre (0, 0, 0); // On part d'une fenetre remplie de noir, et on efface la fenêtre avant chaque nouveau dessin.
				affichage(etat);
			}
			break;
		case Clavier: // Une touche du clavier a ete pressee
			{
				switch (caractereClavier())
				{
					case 'Q': /* Pour sortir quelque peu proprement du programme */
					case 'q':
						exit(0);
						break;

					case 'R':
					case 'r':
						rafraichisFenetre(); // Demande explicite de reaffichage
						break;
			
					case 'H':
					case 'h':	
						affiche_menu();
						break;

					case 'P':
					case 'p':{
						break;
					}

					case 'A':
					case 'a':{
					
					}
						break;
				}
			}
			break;
		case BoutonSouris:{
			if (etatBoutonSouris() == GaucheAppuye)
			{
				//printf("Bouton gauche appuye en : (%d, %d)\n", abscisseSouris(), ordonneeSouris());
				etat=gereClicBoutons(etat);
			}
			else if (etatBoutonSouris() == GaucheRelache)
			{
				//printf("Bouton gauche relache en : (%d, %d)\n", abscisseSouris(), ordonneeSouris());
			}
			
		
		}	
		case Inactivite:
		case Souris:{
			if(etatBoutonSouris()==0){
				gestion_palet(abscisseSouris());
			}
			gestion_palet2();
			gestion_palet3();
		}
		case Redimensionnement:
		case ClavierSpecial:
			 break;
	}
}

#ifndef CASSE_BRIQUE_H
#define CASSE_BRIQUE_H

#include <stdio.h>

#include <string.h>

#include <math.h>

#include <stdlib.h>

#include <stdbool.h>

#include "GfxLib.h"

#include "ESLib.h"

#include "BmpLib.h"

#include "ErreurLib.h"

typedef struct T_RVB
{ 
	int red;
	int green;
	int blue;
}T_RVB;

typedef struct T_BALLE 
{	
	T_RVB color;
	double pos_x;
	double pos_y;
	double vx;
	double vy;
	double v_min;
	double v_max;
	double taille;
}T_balle;

typedef struct T_PALET
{
	T_RVB color;
	double taille_x;
	double taille_y;
	double pos_x;
	double pos_y;
}T_palet;

typedef struct T_BRIQUE
{
	T_RVB color;
	double taille_x;
	double taille_y;
	double pos_x;
	double pos_y;
}T_brique;



/* Les prototypes des fonctions que nous aurons a ecrire */
void affiche_menu();
void dessineBalle();
void dessineBalleAnimee();
int rebondissement();
void tracePalet();
int gereClicBoutons(int etat);
void affichage(int etat);
void initImage();
void gestion_palet(float abs);
void gestion_palet2();
void gestion_palet3();
void niveau1_1();
int gestion_rebondissement_brique();

#endif

#include "casse_brique.h"

static T_palet palet={ {0, 255, 0} , 100, 15, 250, 20};
static T_balle balle={ {255, 0, 0} , 300, 46, 2, 2, 1, 100, 20};
static T_brique brique={ {0, 0, 0}, 115, 30, 0, 0};
static DonneesImageRGB *image = NULL;
static DonneesImageRGB *image1 = NULL;
static DonneesImageRGB *image2 = NULL;
///static DonneesImageRGB *image3 = NULL;
//static DonneesImageRGB *image4 = NULL;

void affiche_menu(){
		sautDeLigne();
     	ecrisChaine("*************  TP GRAPHIQUE ******** \n");
     	ecrisChaine("taper h	pour afficher ce menu    :\n");
     	ecrisChaine("taper r	pour rafraichir la fenêtre graphique    :\n");
     	ecrisChaine("taper q    pour  SORTIR de l'APPLICATION  : \n");
		ecrisChaine("taper p    pour  dessiner un point rouge au centre de la fenêtre  : \n");
		ecrisChaine("taper a    pour  dessiner une balle au centre de la fenêtre  : \n");   
     	sautDeLigne();   
     
}
void dessineBalle(T_balle *balle){

	epaisseurDeTrait(balle->taille);
	couleurCourante(balle->color.red, balle->color.green, balle->color.blue);
	point(balle->pos_x, balle->pos_y);
	rafraichisFenetre();
}

void dessineBalleAnimee(T_balle *balle, T_palet *palet, T_brique *brique){
	
	if(rebondissement(balle, palet)==1 || niveau1_1(brique, balle)==1){
		balle->vy = -balle->vy;
	}
	if(rebondissement(balle, palet)==2){
		balle->vx = -balle->vx;
	}
	balle->pos_x += balle->vx;
	balle->pos_y += balle->vy;
	dessineBalle(balle);
}

int rebondissement(T_balle *balle, T_palet *palet){

	int rebondis=0;
	if(balle->pos_y + balle->taille/2 >= hauteurFenetre() // on vérifie si la balle arrive en haut de la fenetre
	|| (balle->pos_y <= palet->pos_y + palet->taille_y // on verifie si la balle arrive à la hauteur du palet
		&& balle->pos_y >= palet->pos_y
		&& balle->pos_x >= palet->pos_x // on vérifie si elle tombe entre les deux extremités du palet
		&& balle->pos_x <= palet->pos_x + palet->taille_x)){
		rebondis=1;
	}
	if(balle->pos_x /*+ balle->taille/2*/ >= largeurFenetre()  || balle->pos_x /*- balle->taille/2*/ < 0){
		rebondis=2;
	}
	return rebondis;
}

void tracePalet(T_palet *palet){
	couleurCourante(palet->color.red, palet->color.green, palet->color.blue);
	rectangle(palet->pos_x, palet->pos_y, palet->pos_x + palet->taille_x, palet->pos_y + palet->taille_y);
	rafraichisFenetre();
		
}

int gereClicBoutons(int etat) {
if(etat==2)//Menu avec les différents niveaux de difficultés
{

if(abscisseSouris() >= 535 && abscisseSouris() <= 1385 && ordonneeSouris() >= 503 && ordonneeSouris() <= 648) { // Coordonées Bouton Niveau Facile

}

if(abscisseSouris() >= 535 && abscisseSouris() <= 1385 && ordonneeSouris() >= 308 && ordonneeSouris() <= 455) { // Coordonées Bouton Niveau Moyen

}

if(abscisseSouris() >= 535 && abscisseSouris() <= 1385 && ordonneeSouris() >= 113 && ordonneeSouris() <= 256) { // Coordonées Bouton Niveau Difficile

}


if(abscisseSouris() >= 95 && abscisseSouris() <= 275 && ordonneeSouris() >= 808 && ordonneeSouris() <= 962) {  // Coordonées Retour en arrière
 	etat=1;
}

}

if(etat==1)//Menu niveaux de difficultés ou aléatoires
{
if(abscisseSouris() >= 447 && abscisseSouris() <= 1475 && ordonneeSouris() >= 458 && ordonneeSouris() <= 631) { // Coordonées Bouton Niveaux Aléatoires
	etat=3;
}

if(abscisseSouris() >= 447 && abscisseSouris() <= 1475 && ordonneeSouris() >= 205 && ordonneeSouris() <= 381) {  // Coordonées Bouton Niveaux De Difficulté
	etat=2;
}

if(abscisseSouris() >= 95 && abscisseSouris() <= 275 && ordonneeSouris() >= 808 && ordonneeSouris() <= 962) {  // Coordonées Retour en arrière
 	etat=0;
}

}

if(etat==0)// Menu Principale
{
if(abscisseSouris() >= 439 && abscisseSouris() <= 1477 && ordonneeSouris() >= 153 && ordonneeSouris() <= 330) { // Coordonées Bouton Quitter
exit(0);
}

if(abscisseSouris() >= 439 && abscisseSouris() <= 900 && ordonneeSouris() >= 431 && ordonneeSouris() <= 615) {  // Coordonées Bouton Jouer
 etat=1;
}

if(abscisseSouris() >= 1020 && abscisseSouris() <= 1477 && ordonneeSouris() >= 431 && ordonneeSouris() <= 615) {  // Coordonées Bouton Scores

}

}


return etat;
}

void affichage(int etat){

	switch(etat){
	case 0:
	if (image != NULL) // Si l'image a pu etre lue
				{
						// On affiche l'image
						ecrisImage(0, 0, image->largeurImage, image->hauteurImage, image->donneesRGB);
				}
	 break;

	case 1:
	if (image1 != NULL) // Si l'image a pu etre lue
				{
						// On affiche l'image
						ecrisImage(0, 0, image1->largeurImage, image1->hauteurImage, image1->donneesRGB);
				}
	 break;

	 case 2:
	if (image2 != NULL) // Si l'image a pu etre lue
				{
						// On affiche l'image
						ecrisImage(0, 0, image2->largeurImage, image2->hauteurImage, image2->donneesRGB);
				}
	 break;
	 
	 case 3:{
	 	dessineBalleAnimee(&balle, &palet, &brique); //on dessine la balle à partir de la structure, la structure ce met à jour à chaque nouveau dessin.
		tracePalet(&palet);
		niveau1_1(&brique, &balle);
		break;
	 }
		}
}

void initImage(){
	image = lisBMPRGB("image_menu/menu.bmp");
	image1 = lisBMPRGB("image_menu/menuniveaux.bmp");
	image2 = lisBMPRGB("image_menu/facile.bmp");
	//image3 = lisBMPRGB("image_menu/moyen.bmp");
	//image4 = lisBMPRGB("image_menu/difficile.bmp");
}

void gestion_palet(float abs){
	abs = abscisseSouris();
	palet.pos_x = abs - (palet.taille_x/2);
}

void gestion_palet2(){
if(palet.pos_x + palet.taille_x >= largeurFenetre()){
	palet.pos_x = largeurFenetre() - palet.taille_x;
}
}

void gestion_palet3(){
if(palet.pos_x <= 0){
	palet.pos_x =0;
}
}

int niveau1_1(T_brique *brique, T_balle *balle){
	int rebondis=0;
	
	brique->color.red=255;
	brique->color.blue=0;
	brique->color.green=0;
	brique->pos_x=100;
	brique->pos_y=hauteurFenetre()-100;
	rebondis = gestion_rebondissement_brique(brique, balle);
	
	brique->color.red=255;
	brique->color.blue=0;
	brique->color.green=0;
	brique->pos_x=217;
	brique->pos_y=hauteurFenetre()-100;
	rebondis = gestion_rebondissement_brique(brique, balle);
	
	brique->color.red=155;
	brique->color.blue=0;
	brique->color.green=0;
	brique->pos_x=334;
	brique->pos_y=hauteurFenetre()-100;
	rebondis = gestion_rebondissement_brique(brique, balle);
	
	brique->color.red=155;
	brique->color.blue=0;
	brique->color.green=0;
	brique->pos_x=451;
	brique->pos_y=hauteurFenetre()-100;
	rebondis = gestion_rebondissement_brique(brique, balle);
	
	brique->color.red=55;
	brique->color.blue=0;
	brique->color.green=0;
	brique->pos_x=568;
	brique->pos_y=hauteurFenetre()-100;
	rebondis = gestion_rebondissement_brique(brique, balle);

return rebondis;
}

int gestion_rebondissement_brique(T_brique *brique, T_balle *balle){
	int rebondis;
	couleurCourante(brique->color.red, brique->color.green, brique->color.blue);
	rectangle(brique->pos_x, brique->pos_y, brique->pos_x + brique->taille_x, brique->pos_y + brique->taille_y);
	if((balle->pos_y <= brique->pos_y + brique->taille_y // on verifie si la balle arrive à la hauteur du palet
		&& balle->pos_y >= brique->pos_y
		&& balle->pos_x >= brique->pos_x // on vérifie si elle tombe entre les deux extremités du palet
		&& balle->pos_x <= brique->pos_x + brique->taille_x)){
		rebondis=1;
		
}
return rebondis;
}




